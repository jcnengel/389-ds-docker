"""
   :Requirement: 389-ds-base: 389-ds-base: Operational Attributes
"""
