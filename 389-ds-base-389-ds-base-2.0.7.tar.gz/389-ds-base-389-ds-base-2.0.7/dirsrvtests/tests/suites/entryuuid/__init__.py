"""
   :Requirement: 389-ds-base: Entry uuid
"""
