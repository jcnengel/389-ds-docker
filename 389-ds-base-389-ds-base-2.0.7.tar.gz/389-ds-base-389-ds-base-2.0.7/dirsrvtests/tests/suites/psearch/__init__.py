"""
   :Requirement: 389-ds-base: Persistent Search control
"""
