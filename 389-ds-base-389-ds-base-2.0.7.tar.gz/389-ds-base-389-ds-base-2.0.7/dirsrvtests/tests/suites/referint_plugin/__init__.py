"""
   :Requirement: 389-ds-base: Referential Integrity Plugin
"""
