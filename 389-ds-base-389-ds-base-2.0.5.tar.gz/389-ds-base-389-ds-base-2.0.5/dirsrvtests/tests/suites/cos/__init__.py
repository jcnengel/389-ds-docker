"""
   :Requirement: 389-ds-base: Class of Service
"""
