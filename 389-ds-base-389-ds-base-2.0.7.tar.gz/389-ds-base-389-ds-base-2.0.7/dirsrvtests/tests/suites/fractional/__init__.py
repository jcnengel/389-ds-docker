"""
   :Requirement: 389-ds-base: Fractional replication
"""
